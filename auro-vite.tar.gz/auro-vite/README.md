# Auro — Income Intelligence

A premium dark-themed income path advisor with Firebase authentication.

## Project Structure

```
auro/
├── index.html          # Vite entry point
├── vite.config.js      # Vite configuration
├── package.json        # Dependencies and scripts
├── vercel.json         # Vercel SPA routing
└── src/
    ├── main.jsx        # React root mount
    ├── App.jsx         # Main application (quiz, tracking, AI chat, account)
    ├── AuthScreen.jsx  # Sign in / Sign up / Email verification UI
    └── firebase.js     # Firebase init + auth helpers
```

## Getting Started

```bash
npm install
npm run dev
```

App runs at http://localhost:5173

## Build for Production

```bash
npm run build
npm run preview   # preview the production build locally
```

## Deploy to Vercel

### Option 1 — Vercel CLI
```bash
npm i -g vercel
vercel
```

### Option 2 — Git push (recommended)
1. Push this repo to GitHub / GitLab / Bitbucket
2. Import the project at https://vercel.com/new
3. Vercel auto-detects Vite — no configuration needed
4. Deploy

`vercel.json` is already configured for SPA routing.

## Firebase

Firebase config is in `src/firebase.js`. The project uses:
- Firebase Authentication (email/password + email verification)

No additional Firebase console setup is needed beyond what's already configured —
Authentication → Email/Password provider must be **enabled** in the Firebase console.

To enable it:
1. Go to https://console.firebase.google.com/project/auro-929ae
2. Authentication → Sign-in method → Email/Password → Enable
